from flask import Flask
from flask import render_template
from flask import request
from flask_socketio import SocketIO
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
import os
import googlemaps

import json, requests
app=Flask(__name__)
app.config['SECRET_KEY'] = 'vnkdjnfjknfl1232#'
socketio = SocketIO(app)
database_uri = 'postgresql+psycopg2://{dbuser}:{dbpass}@{dbhost}/{dbname}'.format(
    dbuser=os.environ['DBUSER'],
    dbpass=os.environ['DBPASS'],
    dbhost=os.environ['DBHOST'],
    dbname=os.environ['DBNAME']
)
app.config.update(
    SQLALCHEMY_DATABASE_URI=database_uri,
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
)

# initialize the database connection
db = SQLAlchemy(app)

# initialize database migration management
migrate = Migrate(app, db)
@app.route("/",methods=['POST', 'GET'])
def form():
	return render_template("form.html")

@app.route("/insert", methods=['POST', 'GET'])
def insert():
	address=(request.form['address'])
	info=request.form['info']
	from models import Guest
	print(Guest.__tablename__)
	guest = Guest(address, info)
	db.session.add(guest)
	db.session.commit()
	return render_template("form.html")
@app.route("/map", methods=['POST', 'GET'])
def map():
	from models import Guest
	address = Guest.query.with_entities(Guest.name).all()
	
	#print(address, type(address))
	addr=[]	
	for add in address:
		addr.append(add[0])
	print(addr)
	info= Guest.query.with_entities(Guest.email).all()
	
	information=[]
	for inf in info:
		information.append(inf[0])
	print(information, len(information))
	gmaps = googlemaps.Client(key='AIzaSyAef5QTmsK376KK-53594VgCfHKn6nE71k') #connecting to google client
	lat_lng=[]
	import json
	for add in addr:
		geocode_result=(gmaps.geocode(add))
		#gr=json.dumps(geocode_result)
		#print(gr[0].geometry)
		lat_lng.append([[[float(d['geometry']['location']['lat'])], [float(d['geometry']['location']['lng'])]] for d in geocode_result])
	print(len(lat_lng),lat_lng[0])
	ll=[]
	#keys=["lat","lng"]
	#ll=dict.fromkeys(keys,[])
	#print(ll)
	import collections
	for i in range(0,len(lat_lng)):
		ll1={}
		if(lat_lng[i]):
			ll1["lat"]=lat_lng[i][0][0][0]
			ll1["lng"]=lat_lng[i][0][1][0]
			ll1["info"]=information[i]
			ll.append(ll1)
			print (i,lat_lng[i][0][0][0],lat_lng[i][0][1][0])
	print(ll)
	jl=json.dumps(ll)
	#jl=json.loads(jl)
	
	#print("json", jl[0].lat)
	#return render_template("map.html", lat_lng=lat_lng)
	from flask import Response
	return render_template("home.html",ll=json.loads(jl))

@app.route("/weather_api", methods=['POST', 'GET'])
def form_weather():
	return render_template("date.html")

@app.route("/weather",methods=['POST','GET'])
def weather():
	dateFrom=request.form['from']
	print(dateFrom)
	dateTo=request.form['to']
	import dateutil.parser as parser
	date = parser.parse(dateFrom)
	dateFrom=date.isoformat()
	date=parser.parse(dateTo)
	dateTo=date.isoformat()
	print(dateFrom, dateTo)
	url="https://api.reliefweb.int/v1/reports?appname=apidoc&filter[operator]=OR&filter[conditions][0][operator]=AND&filter[conditions][0][conditions][0][field]=primary_country&filter[conditions][0][conditions][1][operator]=OR&filter[conditions][0][conditions][1][field]=date&filter[conditions][0][conditions][1][value][from]={}%2B00:00&filter[conditions][0][conditions][1][value][to]={}%2B00:00&fields[include][]=country.name&fields[include][]=primary_country.name&fields[include][]=headline.title&fields[include][]=disaster.name&fields[include][]=disaster_type.name&fields[include][]=date.original".format(dateFrom,dateTo)
	#print(url)
	response = json.loads(requests.get(url).text)
	response1=json.dumps(response)
	response=json.dumps(response["data"])
	#print(json.loads(response))
	res_load=json.loads(response)
	#print(res_load)
	res_json=[]
	res_disas=[]
	gmaps = googlemaps.Client(key='AIzaSyAef5QTmsK376KK-53594VgCfHKn6nE71k')
	for item in res_load:
		
		for data,value in item["fields"].iteritems():
			#ll2={}
			#print("data",data, "value", value)
			#ll2[data]=value
			
			if(data =="primary_country"):
				for key,val in value.iteritems():
					print(key,val)
					ll1={}
					ll1["country"]=val
					#print(ll1)
					res_json.append(ll1)
		#print(len(item))
		for data,value in item["fields"].iteritems():
			#print(len(data),data,value)
			if "title" in data:
					ll2=[]
					ll2.append(value)
					res_disas.append(ll2)
			
	#print(res_json)
	#print(len(res_disas),res_disas)
	rj=json.dumps(res_json)
	lat_lng=[]
	for add in res_json:
		geocode_result=(gmaps.geocode(add["country"]))
		#gr=json.dumps(geocode_result)
		#print(gr[0].geometry)
		lat_lng.append([[[float(d['geometry']['location']['lat'])], [float(d['geometry']['location']['lng'])]] for d in geocode_result])
	
	
	#print(len(lat_lng),lat_lng[7])
	add_info=[]
	#print(res_disas)
	for i in range(0,len(lat_lng)):
		ai={}
		
		if(lat_lng[i]):
			ai["lat"]=lat_lng[i][0][0][0]
			ai["lng"]=lat_lng[i][0][1][0]
			ai["info"]=res_disas[i][0]
			print(i,ai)
		add_info.append(ai)
	print(add_info)	
	add_info=json.dumps(add_info)
	return render_template("api_weather.html", response=json.loads(add_info))

@app.route('/session')
def sessions():
    return render_template('session.html')


def messageReceived(methods=['GET', 'POST']):
    print('message was received!!!')


@socketio.on('my event')
def handle_my_custom_event(json, methods=['GET', 'POST']):
    print('received my event: ' + str(json))
    socketio.emit('my response', json, callback=messageReceived)
if __name__=="__main__":
	
	socketio.run(app, debug=True)
	app.run(host='0.0.0.0', port=8080, debug=True)
